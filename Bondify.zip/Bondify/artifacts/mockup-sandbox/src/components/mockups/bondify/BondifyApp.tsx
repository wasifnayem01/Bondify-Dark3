import { useState, useEffect, useRef, type CSSProperties, type ReactNode } from "react";
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  type User,
  type AuthError,
} from "firebase/auth";
import {
  collection,
  doc,
  addDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  where,
  orderBy,
  serverTimestamp,
  Timestamp,
  getDoc,
  arrayUnion,
} from "firebase/firestore";
import { auth, db, isFirebaseConfigured } from "./_shared/firebase";
import { ProfileTab } from "./ProfileTab";

type Screen = "splash" | "login" | "signup" | "username_setup" | "app" | "chatroom";
type Tab = "home" | "chats" | "people" | "profile";

interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  username: string;
}

type FriendStatus = "none" | "outgoing_pending" | "incoming_pending" | "friends";
type PeopleSubView = "discover" | "requests" | "friends";

interface FriendRequest {
  id: string;
  from: string;
  fromName: string;
  to: string;
  toName: string;
  status: "pending" | "accepted" | "rejected";
  createdAt: Timestamp | null;
}

interface ChatMessage {
  id: string;
  text: string;
  senderId: string;
  senderName: string;
  createdAt: Timestamp | null;
}

interface ChatRoom {
  id: string;
  otherName: string;
  otherInitials: string;
  otherColor: string;
  lastMessage: string;
  lastMessageAt: Timestamp | null;
  unread?: number;
}

function getFirebaseErrorMessage(error: AuthError): string {
  switch (error.code) {
    case "auth/email-already-in-use": return "An account already exists with this email.";
    case "auth/invalid-email": return "Please enter a valid email address.";
    case "auth/wrong-password":
    case "auth/invalid-credential": return "Incorrect email or password.";
    case "auth/user-not-found": return "No account found with this email.";
    case "auth/weak-password": return "Password must be at least 6 characters.";
    case "auth/too-many-requests": return "Too many attempts. Please try again later.";
    case "auth/network-request-failed": return "Network error. Check your connection.";
    default: return "Something went wrong. Please try again.";
  }
}

function validatePassword(password: string): string[] {
  const errors: string[] = [];
  if (password.length < 8) errors.push("At least 8 characters");
  if (!/[A-Z]/.test(password)) errors.push("One uppercase letter");
  if (!/[0-9]/.test(password)) errors.push("One number");
  return errors;
}

const BG = "linear-gradient(160deg, #0c0c1a 0%, #110e1f 60%, #09090f 100%)";
const CARD_BG = "rgba(255,255,255,0.03)";
const BORDER = "rgba(255,255,255,0.07)";
const ACCENT = "#7c3aed";
const ACCENT2 = "#a855f7";
const GRAD = `linear-gradient(135deg, ${ACCENT} 0%, ${ACCENT2} 100%)`;
const TEXT = "#f1f5f9";
const MUTED = "#64748b";
const FIELD_BG = "rgba(255,255,255,0.04)";
const FIELD_FOCUS_BG = "rgba(124,58,237,0.09)";
const FIELD_BORDER = "rgba(255,255,255,0.08)";
const FIELD_FOCUS_BORDER = "rgba(124,58,237,0.65)";
const font = "'Inter', sans-serif";
const LOGO_SRC = "/__mockup/images/bondify-logo.png";

const DEMO_CONTACTS = [
  { id: "demo_alex",  name: "Alex K.",   initials: "AK", color: "#6366f1", status: "Active now" },
  { id: "demo_maria", name: "Maria S.",  initials: "MS", color: "#a855f7", status: "2h ago" },
  { id: "demo_james", name: "James T.",  initials: "JT", color: "#7c3aed", status: "Yesterday" },
];

// ──────────────────────── Shared UI ────────────────────────

interface FieldProps {
  icon: ReactNode;
  type: string;
  placeholder: string;
  value: string;
  onChange: (v: string) => void;
  right?: ReactNode;
}

function Field({ icon, type, placeholder, value, onChange, right }: FieldProps) {
  const [focused, setFocused] = useState(false);
  return (
    <div style={{ position: "relative" }}>
      <div style={{ position: "absolute", left: 15, top: "50%", transform: "translateY(-50%)", color: focused ? "#a78bfa" : MUTED, transition: "color 0.2s", pointerEvents: "none", zIndex: 1 }}>
        {icon}
      </div>
      <input
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        style={{
          width: "100%", background: focused ? FIELD_FOCUS_BG : FIELD_BG,
          border: `1.5px solid ${focused ? FIELD_FOCUS_BORDER : FIELD_BORDER}`,
          borderRadius: 13, padding: right ? "15px 48px 15px 44px" : "15px 16px 15px 44px",
          fontSize: 15, color: TEXT, outline: "none", boxSizing: "border-box",
          transition: "all 0.2s", boxShadow: focused ? "0 0 0 3px rgba(124,58,237,0.13)" : "none", fontFamily: font,
        }}
      />
      {right && <div style={{ position: "absolute", right: 14, top: "50%", transform: "translateY(-50%)" }}>{right}</div>}
    </div>
  );
}

function Btn({ children, onClick, loading, secondary }: { children: ReactNode; onClick?: () => void; loading?: boolean; secondary?: boolean }) {
  return (
    <button onClick={onClick} disabled={loading} style={{
      width: "100%", background: secondary ? "rgba(255,255,255,0.04)" : GRAD,
      border: secondary ? `1.5px solid ${BORDER}` : "none", borderRadius: 13, padding: "16px",
      fontSize: 15, fontWeight: 700, color: secondary ? "#94a3b8" : "#fff",
      cursor: loading ? "not-allowed" : "pointer", opacity: loading ? 0.7 : 1,
      boxShadow: secondary ? "none" : "0 6px 24px rgba(124,58,237,0.38)", transition: "transform 0.12s",
      fontFamily: font,
    }}
      onMouseDown={(e) => !loading && (e.currentTarget.style.transform = "scale(0.98)")}
      onMouseUp={(e) => (e.currentTarget.style.transform = "scale(1)")}
    >
      {loading ? "Please wait…" : children}
    </button>
  );
}

function ErrorBanner({ message }: { message: string }) {
  return (
    <div style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.25)", borderRadius: 10, padding: "11px 14px", display: "flex", alignItems: "flex-start", gap: 9 }}>
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ef4444" strokeWidth="2" strokeLinecap="round" style={{ marginTop: 1, flexShrink: 0 }}>
        <circle cx="12" cy="12" r="10" /><line x1="12" y1="8" x2="12" y2="12" /><line x1="12" y1="16" x2="12.01" y2="16" />
      </svg>
      <span style={{ fontSize: 13, color: "#fca5a5", lineHeight: 1.4 }}>{message}</span>
    </div>
  );
}

function StatusBar() {
  return (
    <div style={{ padding: "14px 24px 0", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
      <span style={{ color: TEXT, fontSize: 13, fontWeight: 600 }}>9:41</span>
      <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
        <svg width="15" height="11" viewBox="0 0 16 12" fill={TEXT}><rect x="0" y="4" width="3" height="8" rx="0.5"/><rect x="4.5" y="2.5" width="3" height="9.5" rx="0.5"/><rect x="9" y="0.5" width="3" height="11.5" rx="0.5"/><rect x="13.5" y="0" width="2.5" height="12" rx="0.5" opacity="0.35"/></svg>
        <div style={{ background: TEXT, borderRadius: 3, width: 22, height: 11, display: "flex", alignItems: "center", padding: "0 2px" }}>
          <div style={{ background: "#0c0c1a", borderRadius: 2, width: 16, height: 7 }} />
        </div>
      </div>
    </div>
  );
}

function Logo({ size = 110 }: { size?: number }) {
  return (
    <div style={{ textAlign: "center", marginBottom: 28 }}>
      <img src={LOGO_SRC} alt="Bondify" style={{ width: size, height: size, objectFit: "contain", display: "block", margin: "0 auto", filter: "drop-shadow(0 8px 24px rgba(168,85,247,0.45))" }} />
    </div>
  );
}

function Divider() {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10, margin: "20px 0" }}>
      <div style={{ flex: 1, height: 1, background: BORDER }} />
      <span style={{ fontSize: 11, color: MUTED, fontWeight: 500, letterSpacing: "0.5px" }}>OR</span>
      <div style={{ flex: 1, height: 1, background: BORDER }} />
    </div>
  );
}

function HomeIndicator() {
  return (
    <div style={{ display: "flex", justifyContent: "center", paddingTop: 20, paddingBottom: 8 }}>
      <div style={{ width: 134, height: 5, borderRadius: 3, background: "rgba(255,255,255,0.18)" }} />
    </div>
  );
}

function Glow({ top, left, right, color }: { top: number; left?: number; right?: number; color: string }) {
  return (
    <div style={{ position: "absolute", top, left, right, width: 260, height: 260, borderRadius: "50%", background: `radial-gradient(circle, ${color} 0%, transparent 70%)`, pointerEvents: "none" }} />
  );
}

function Avatar({ initials, color, size = 44 }: { initials: string; color: string; size?: number }) {
  return (
    <div style={{ width: size, height: size, borderRadius: size * 0.32, background: `linear-gradient(135deg, ${color}99, ${color}44)`, border: `1.5px solid ${color}44`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: size * 0.32, fontWeight: 700, color: "#fff", flexShrink: 0 }}>
      {initials}
    </div>
  );
}

// ──────────────────────── Splash Screen ────────────────────────

function SplashScreen({ onDone }: { onDone: () => void }) {
  const [fade, setFade] = useState(false);
  useEffect(() => {
    const t1 = setTimeout(() => setFade(true), 1800);
    const t2 = setTimeout(() => onDone(), 2400);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [onDone]);

  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", transition: "opacity 0.6s ease", opacity: fade ? 0 : 1 }}>
      <style>{`
        @keyframes logoFloat { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-8px)} }
        @keyframes spin { to{transform:rotate(360deg)} }
        @keyframes pulse { 0%,100%{opacity:0.4} 50%{opacity:1} }
        @keyframes fadeIn { from{opacity:0;transform:translateY(10px)} to{opacity:1;transform:translateY(0)} }
        @keyframes slideUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
        @keyframes msgIn { from{opacity:0;transform:translateY(12px) scale(0.96)} to{opacity:1;transform:translateY(0) scale(1)} }
      `}</style>
      <img src={LOGO_SRC} alt="Bondify" style={{ width: 200, height: 200, objectFit: "contain", filter: "drop-shadow(0 12px 40px rgba(168,85,247,0.55))", animation: "logoFloat 2.5s ease-in-out infinite" }} />
      <div style={{ marginTop: 48, display: "flex", gap: 8 }}>
        {[0, 1, 2].map((i) => (
          <div key={i} style={{ width: 7, height: 7, borderRadius: "50%", background: GRAD, animation: `pulse 1.2s ease-in-out ${i * 0.2}s infinite` }} />
        ))}
      </div>
    </div>
  );
}

// ──────────────────────── Auth Screens ────────────────────────

function LoginScreen({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleLogin = async () => {
    setError("");
    if (!email.trim()) { setError("Please enter your email."); return; }
    if (!password) { setError("Please enter your password."); return; }
    setLoading(true);
    try { await signInWithEmailAndPassword(auth, email.trim(), password); }
    catch (e) { setError(getFirebaseErrorMessage(e as AuthError)); }
    finally { setLoading(false); }
  };

  const eyeHide = <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"/><path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"/><line x1="2" y1="2" x2="22" y2="22"/></svg>;
  const eyeShow = <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>;

  return (
    <div style={{ flex: 1, padding: "0 26px", display: "flex", flexDirection: "column" }}>
      <div style={{ marginTop: 40, marginBottom: 32 }}>
        <Logo />
        <h2 style={{ fontSize: 22, fontWeight: 700, color: TEXT, margin: "0 0 4px", letterSpacing: "-0.3px" }}>Welcome back</h2>
        <p style={{ fontSize: 14, color: MUTED, margin: 0 }}>Sign in to your account</p>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {error && <ErrorBanner message={error} />}
        <Field icon={<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><rect x="2" y="4" width="20" height="16" rx="3"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>} type="email" placeholder="Email address" value={email} onChange={setEmail} />
        <Field icon={<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>} type={showPw ? "text" : "password"} placeholder="Password" value={password} onChange={setPassword}
          right={<button onClick={() => setShowPw(!showPw)} style={{ background: "none", border: "none", cursor: "pointer", color: MUTED, padding: 0, display: "flex" }}>{showPw ? eyeHide : eyeShow}</button>} />
        <div style={{ textAlign: "right" }}>
          <button style={{ background: "none", border: "none", fontSize: 13, color: "#a78bfa", cursor: "pointer", padding: 0, fontWeight: 500, fontFamily: font }}>Forgot password?</button>
        </div>
        <Btn onClick={handleLogin} loading={loading}>Sign In</Btn>
        <Divider />
        <div style={{ display: "flex", gap: 10 }}>
          {[
            { label: "Google", icon: <svg width="18" height="18" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg> },
            { label: "Apple", icon: <svg width="18" height="18" viewBox="0 0 24 24" fill={TEXT}><path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/></svg> },
          ].map((s) => (
            <button key={s.label} style={{ flex: 1, background: FIELD_BG, border: `1.5px solid ${BORDER}`, borderRadius: 13, padding: "12px", display: "flex", alignItems: "center", justifyContent: "center", gap: 8, cursor: "pointer", color: "#94a3b8", fontSize: 14, fontWeight: 500, fontFamily: font }}>
              {s.icon}{s.label}
            </button>
          ))}
        </div>
      </div>
      <div style={{ marginTop: "auto", paddingTop: 24, textAlign: "center" }}>
        <span style={{ fontSize: 14, color: MUTED }}>Don't have an account? </span>
        <button onClick={() => onNavigate("signup")} style={{ background: "none", border: "none", fontSize: 14, fontWeight: 700, color: "#a78bfa", cursor: "pointer", padding: 0, fontFamily: font }}>Sign Up</button>
      </div>
      <HomeIndicator />
    </div>
  );
}

function SignupScreen({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [pwErrors, setPwErrors] = useState<string[]>([]);

  const eyeHide = <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"/><path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"/><line x1="2" y1="2" x2="22" y2="22"/></svg>;
  const eyeShow = <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>;

  const handleSignup = async () => {
    setError("");
    if (!name.trim()) { setError("Please enter your name."); return; }
    if (!email.trim()) { setError("Please enter your email."); return; }
    const errs = validatePassword(password);
    if (errs.length) { setError("Password doesn't meet requirements."); return; }
    if (password !== confirm) { setError("Passwords don't match."); return; }
    setLoading(true);
    try {
      const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
      await setDoc(doc(db, "users", cred.user.uid), { displayName: name.trim(), email: email.trim(), createdAt: serverTimestamp() });
    } catch (e) { setError(getFirebaseErrorMessage(e as AuthError)); }
    finally { setLoading(false); }
  };

  return (
    <div style={{ flex: 1, padding: "0 26px", display: "flex", flexDirection: "column", overflowY: "auto" }}>
      <div style={{ marginTop: 40, marginBottom: 28 }}>
        <Logo />
        <h2 style={{ fontSize: 22, fontWeight: 700, color: TEXT, margin: "0 0 4px", letterSpacing: "-0.3px" }}>Create account</h2>
        <p style={{ fontSize: 14, color: MUTED, margin: 0 }}>Join the Bondify community</p>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 11 }}>
        {error && <ErrorBanner message={error} />}
        <Field icon={<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 3.58-7 8-7s8 3 8 7"/></svg>} type="text" placeholder="Full name" value={name} onChange={setName} />
        <Field icon={<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><rect x="2" y="4" width="20" height="16" rx="3"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>} type="email" placeholder="Email address" value={email} onChange={setEmail} />
        <Field icon={<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>} type={showPw ? "text" : "password"} placeholder="Password" value={password}
          onChange={(v) => { setPassword(v); setPwErrors(v ? validatePassword(v) : []); }}
          right={<button onClick={() => setShowPw(!showPw)} style={{ background: "none", border: "none", cursor: "pointer", color: MUTED, padding: 0, display: "flex", fontFamily: font }}>{showPw ? eyeHide : eyeShow}</button>} />
        {password && pwErrors.length > 0 && (
          <div style={{ background: "rgba(251,191,36,0.07)", border: "1px solid rgba(251,191,36,0.18)", borderRadius: 10, padding: "10px 14px" }}>
            <p style={{ fontSize: 12, color: "#fbbf24", margin: "0 0 6px", fontWeight: 600 }}>Password needs:</p>
            {(["At least 8 characters", "One uppercase letter", "One number"] as const).map((rule) => {
              const missing = pwErrors.includes(rule);
              return (
                <div key={rule} style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 3 }}>
                  <div style={{ width: 14, height: 14, borderRadius: "50%", background: missing ? "rgba(251,191,36,0.15)" : "rgba(52,211,153,0.15)", border: `1px solid ${missing ? "rgba(251,191,36,0.4)" : "rgba(52,211,153,0.4)"}`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                    {missing ? <svg width="8" height="8" viewBox="0 0 8 8"><line x1="2" y1="2" x2="6" y2="6" stroke="#fbbf24" strokeWidth="1.5" strokeLinecap="round"/><line x1="6" y1="2" x2="2" y2="6" stroke="#fbbf24" strokeWidth="1.5" strokeLinecap="round"/></svg>
                      : <svg width="8" height="8" viewBox="0 0 8 8"><polyline points="1.5,4 3.5,6 7,2" stroke="#34d399" strokeWidth="1.5" fill="none" strokeLinecap="round"/></svg>}
                  </div>
                  <span style={{ fontSize: 12, color: missing ? "#fbbf24" : "#34d399" }}>{rule}</span>
                </div>
              );
            })}
          </div>
        )}
        <Field icon={<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>} type="password" placeholder="Confirm password" value={confirm} onChange={setConfirm} />
        {confirm && password && confirm !== password && <p style={{ fontSize: 12, color: "#fca5a5", margin: "-4px 0 0 4px" }}>Passwords don't match</p>}
        <div style={{ marginTop: 2 }}><Btn onClick={handleSignup} loading={loading}>Create Account</Btn></div>
      </div>
      <div style={{ marginTop: "auto", paddingTop: 20, textAlign: "center" }}>
        <span style={{ fontSize: 14, color: MUTED }}>Already have an account? </span>
        <button onClick={() => onNavigate("login")} style={{ background: "none", border: "none", fontSize: 14, fontWeight: 700, color: "#a78bfa", cursor: "pointer", padding: 0, fontFamily: font }}>Sign In</button>
      </div>
      <HomeIndicator />
    </div>
  );
}

// ──────────────────────── Username Setup Screen ────────────────────────

function UsernameSetupScreen({ user, onComplete }: { user: User; onComplete: () => void }) {
  const [value, setValue] = useState("");
  const [avail, setAvail] = useState<"idle" | "checking" | "available" | "taken" | "invalid">("idle");
  const [saving, setSaving] = useState(false);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const VALID_RE = /^[a-zA-Z0-9_]{3,20}$/;

  const handleChange = (raw: string) => {
    const v = raw.replace(/[^a-zA-Z0-9_]/g, "").toLowerCase().slice(0, 20);
    setValue(v);
    if (timerRef.current) clearTimeout(timerRef.current);
    if (!v) { setAvail("idle"); return; }
    if (!VALID_RE.test(v)) { setAvail("invalid"); return; }
    setAvail("checking");
    timerRef.current = setTimeout(async () => {
      try {
        const snap = await getDoc(doc(db, "usernames", v));
        setAvail(snap.exists() && snap.data().uid !== user.uid ? "taken" : "available");
      } catch { setAvail("available"); }
    }, 500);
  };

  const handleSubmit = async () => {
    if (avail !== "available" || saving) return;
    setSaving(true);
    try {
      await setDoc(doc(db, "users", user.uid), { username: value }, { merge: true });
      await setDoc(doc(db, "usernames", value), { uid: user.uid });
      onComplete();
    } finally { setSaving(false); }
  };

  const canSubmit = avail === "available" && !saving;
  const statusColor = { idle: "transparent", checking: "#fbbf24", available: "#34d399", taken: "#fca5a5", invalid: "#fca5a5" }[avail];
  const statusMsg = { idle: "", checking: "Checking availability…", available: "✓ Available — great pick!", taken: "✗ Already taken", invalid: "✗ 3–20 characters, letters, numbers and _ only" }[avail];

  const borderColor = avail === "available" ? "rgba(52,211,153,0.55)" : avail === "taken" || avail === "invalid" ? "rgba(239,68,68,0.45)" : FIELD_FOCUS_BORDER;
  const shadow = avail === "available" ? "0 0 0 3px rgba(52,211,153,0.1)" : avail === "taken" || avail === "invalid" ? "0 0 0 3px rgba(239,68,68,0.08)" : "0 0 0 3px rgba(124,58,237,0.12)";

  const rules = [
    { label: "3–20 characters", ok: value.length >= 3 && value.length <= 20 },
    { label: "Letters, numbers and _ only", ok: value.length > 0 && /^[a-zA-Z0-9_]+$/.test(value) },
    { label: "No spaces allowed", ok: value.length > 0 && !value.includes(" ") },
  ];

  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", padding: "0 26px", overflowY: "auto" }}>
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      <div style={{ marginTop: 48, marginBottom: 32, textAlign: "center" }}>
        <Logo />
        <h2 style={{ fontSize: 22, fontWeight: 700, color: TEXT, margin: "0 0 6px", letterSpacing: "-0.3px" }}>Pick your @username</h2>
        <p style={{ fontSize: 14, color: MUTED, margin: 0, lineHeight: 1.5 }}>This is how people find you on Bondify</p>
      </div>

      <div style={{ display: "flex", alignItems: "center", background: FIELD_BG, border: `2px solid ${borderColor}`, borderRadius: 14, overflow: "hidden", transition: "all 0.2s", boxShadow: shadow, marginBottom: 8 }}>
        <span style={{ padding: "16px 4px 16px 18px", fontSize: 20, fontWeight: 700, color: ACCENT2, userSelect: "none" as const, flexShrink: 0 }}>@</span>
        <input
          value={value} onChange={(e) => handleChange(e.target.value)}
          placeholder="yourname" autoFocus
          onKeyDown={(e) => e.key === "Enter" && handleSubmit()}
          style={{ flex: 1, background: "none", border: "none", outline: "none", fontSize: 18, fontWeight: 600, color: TEXT, padding: "16px 12px 16px 2px", fontFamily: font }}
        />
        {avail === "checking" && (
          <div style={{ paddingRight: 14 }}>
            <div style={{ width: 16, height: 16, borderRadius: "50%", border: `2px solid rgba(255,255,255,0.1)`, borderTopColor: ACCENT, animation: "spin 0.7s linear infinite" }} />
          </div>
        )}
      </div>

      <div style={{ minHeight: 22, marginBottom: 14 }}>
        {statusMsg && <p style={{ fontSize: 13, color: statusColor, margin: 0, fontWeight: 500, transition: "color 0.2s" }}>{statusMsg}</p>}
      </div>

      <div style={{ background: FIELD_BG, border: `1px solid ${BORDER}`, borderRadius: 12, padding: "13px 16px", marginBottom: 28 }}>
        {rules.map(({ label, ok }) => (
          <div key={label} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 7 }}>
            <div style={{ width: 16, height: 16, borderRadius: "50%", background: ok ? "rgba(52,211,153,0.15)" : "rgba(255,255,255,0.05)", border: `1.5px solid ${ok ? "rgba(52,211,153,0.5)" : BORDER}`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, transition: "all 0.2s" }}>
              {ok && <svg width="8" height="8" viewBox="0 0 8 8"><polyline points="1.5,4 3.5,6 7,2" stroke="#34d399" strokeWidth="1.5" fill="none" strokeLinecap="round"/></svg>}
            </div>
            <span style={{ fontSize: 12, color: ok ? "#34d399" : MUTED, transition: "color 0.2s" }}>{label}</span>
          </div>
        ))}
      </div>

      <button onClick={handleSubmit} disabled={!canSubmit} style={{
        width: "100%", background: canSubmit ? GRAD : "rgba(124,58,237,0.12)",
        border: `1px solid ${canSubmit ? "transparent" : ACCENT + "33"}`,
        borderRadius: 14, padding: "17px", fontSize: 16, fontWeight: 700,
        color: canSubmit ? "#fff" : MUTED, cursor: canSubmit ? "pointer" : "default",
        fontFamily: font, boxShadow: canSubmit ? "0 8px 28px rgba(124,58,237,0.42)" : "none",
        transition: "all 0.3s",
      }}>
        {saving ? "Setting up your account…" : "Continue →"}
      </button>
    </div>
  );
}

// ──────────────────────── Find Friends Screen ────────────────────────

const USER_COLORS = ["#6366f1", "#a855f7", "#7c3aed", "#ec4899", "#3b82f6", "#10b981", "#f59e0b"];
function uidColor(uid: string) {
  let h = 0;
  for (let i = 0; i < uid.length; i++) h = (h * 31 + uid.charCodeAt(i)) >>> 0;
  return USER_COLORS[h % USER_COLORS.length];
}

function FindFriendsScreen({ currentUser, onOpenChat, onPendingCount, blockedUsers, onBlock }: {
  currentUser: User;
  onOpenChat: (id: string, name: string, initials: string, color: string) => void;
  onPendingCount: (n: number) => void;
  blockedUsers: string[];
  onBlock: (uid: string) => void;
}) {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [outgoing, setOutgoing] = useState<FriendRequest[]>([]);
  const [incoming, setIncoming] = useState<FriendRequest[]>([]);
  const [search, setSearch] = useState("");
  const [fsError, setFsError] = useState("");
  const [acting, setActing] = useState<string | null>(null);
  const [subView, setSubView] = useState<PeopleSubView>("discover");

  const requests = [...outgoing, ...incoming];

  const getStatus = (uid: string): FriendStatus => {
    for (const r of requests) {
      if (r.status === "accepted" && (r.from === uid || r.to === uid)) return "friends";
      if (r.status === "pending" && r.from === currentUser.uid && r.to === uid) return "outgoing_pending";
      if (r.status === "pending" && r.to === currentUser.uid && r.from === uid) return "incoming_pending";
    }
    return "none";
  };

  const getRequest = (uid: string) =>
    requests.find((r) => r.status === "pending" && (
      (r.from === currentUser.uid && r.to === uid) ||
      (r.to === currentUser.uid && r.from === uid)
    ));

  // Load all users
  useEffect(() => {
    const unsub = onSnapshot(collection(db, "users"), (snap) => {
      const list: UserProfile[] = [];
      snap.forEach((d) => {
        if (d.id === currentUser.uid) return;
        const data = d.data();
        list.push({ uid: d.id, displayName: data.displayName ?? "Unknown", email: data.email ?? "", username: data.username ?? "" });
      });
      list.sort((a, b) => a.displayName.localeCompare(b.displayName));
      setUsers(list);
    }, (err) => setFsError(err.code === "permission-denied"
      ? "Firestore not enabled yet — enable it in your Firebase Console with the security rules from the setup guide."
      : `Could not load users: ${err.message}`));
    return unsub;
  }, [currentUser.uid]);

  // Load outgoing requests
  useEffect(() => {
    const q = query(collection(db, "friendRequests"), where("from", "==", currentUser.uid));
    return onSnapshot(q, (snap) => {
      setOutgoing(snap.docs.map((d) => ({ id: d.id, ...d.data() } as FriendRequest)));
    }, () => {});
  }, [currentUser.uid]);

  // Load incoming requests
  useEffect(() => {
    const q = query(collection(db, "friendRequests"), where("to", "==", currentUser.uid));
    return onSnapshot(q, (snap) => {
      const list = snap.docs.map((d) => ({ id: d.id, ...d.data() } as FriendRequest));
      setIncoming(list);
      onPendingCount(list.filter((r) => r.status === "pending").length);
    }, () => {});
  }, [currentUser.uid, onPendingCount]);

  const sendRequest = async (other: UserProfile) => {
    setActing(other.uid);
    try {
      const myName = currentUser.displayName || currentUser.email?.split("@")[0] || "Me";
      await addDoc(collection(db, "friendRequests"), {
        from: currentUser.uid, fromName: myName,
        to: other.uid, toName: other.displayName,
        status: "pending", createdAt: serverTimestamp(),
      });
    } finally { setActing(null); }
  };

  const cancelRequest = async (other: UserProfile) => {
    setActing(other.uid);
    try {
      const req = getRequest(other.uid);
      if (req) await deleteDoc(doc(db, "friendRequests", req.id));
    } finally { setActing(null); }
  };

  const respondRequest = async (requestId: string, accept: boolean) => {
    setActing(requestId);
    try {
      await updateDoc(doc(db, "friendRequests", requestId), { status: accept ? "accepted" : "rejected" });
      if (accept) {
        const req = requests.find((r) => r.id === requestId);
        if (req) {
          const chatId = [currentUser.uid, req.from].sort().join("_");
          await setDoc(doc(db, "chats", chatId), {
            participants: [currentUser.uid, req.from],
            participantNames: { [currentUser.uid]: req.toName, [req.from]: req.fromName },
            lastMessage: "", lastMessageAt: serverTimestamp(), createdAt: serverTimestamp(),
          }, { merge: true });
        }
      }
    } finally { setActing(null); }
  };

  const openFriendChat = async (other: UserProfile) => {
    setActing(other.uid);
    try {
      const myName = currentUser.displayName || currentUser.email?.split("@")[0] || "Me";
      const chatId = [currentUser.uid, other.uid].sort().join("_");
      await setDoc(doc(db, "chats", chatId), {
        participants: [currentUser.uid, other.uid],
        participantNames: { [currentUser.uid]: myName, [other.uid]: other.displayName },
        lastMessage: "", lastMessageAt: serverTimestamp(), createdAt: serverTimestamp(),
      }, { merge: true });
      onOpenChat(chatId, other.displayName, other.displayName.slice(0, 2).toUpperCase(), uidColor(other.uid));
    } finally { setActing(null); }
  };

  const pendingIncoming = incoming.filter((r) => r.status === "pending");
  const friendUids = new Set(requests.filter((r) => r.status === "accepted").map((r) => r.from === currentUser.uid ? r.to : r.from));
  const blockedSet = new Set(blockedUsers);
  const friendUsers = users.filter((u) => friendUids.has(u.uid) && !blockedSet.has(u.uid));
  const discoverUsers = users.filter((u) => !friendUids.has(u.uid) && !blockedSet.has(u.uid));
  const searchLower = search.toLowerCase().replace(/^@/, "");
  const filtered = search.trim()
    ? discoverUsers.filter((u) =>
        u.displayName.toLowerCase().includes(searchLower) ||
        u.email.toLowerCase().includes(searchLower) ||
        (u.username && u.username.toLowerCase().includes(searchLower))
      )
    : discoverUsers;

  const SubNav = () => (
    <div style={{ display: "flex", margin: "0 22px 16px", background: FIELD_BG, border: `1px solid ${BORDER}`, borderRadius: 12, padding: 3, gap: 2 }}>
      {([["discover", "Discover"], ["friends", `Friends${friendUsers.length > 0 ? ` (${friendUsers.length})` : ""}`], ["requests", `Requests${pendingIncoming.length > 0 ? ` · ${pendingIncoming.length}` : ""}`]] as const).map(([id, label]) => (
        <button key={id} onClick={() => setSubView(id)} style={{
          flex: 1, background: subView === id ? GRAD : "none",
          border: "none", borderRadius: 10, padding: "8px 4px", fontSize: 12, fontWeight: 600,
          color: subView === id ? "#fff" : MUTED, cursor: "pointer", fontFamily: font,
          boxShadow: subView === id ? "0 2px 8px rgba(124,58,237,0.3)" : "none", transition: "all 0.2s",
        }}>{label}</button>
      ))}
    </div>
  );

  const UserCard = ({ u, status }: { u: UserProfile; status: FriendStatus }) => {
    const color = uidColor(u.uid);
    const isActing = acting === u.uid;
    const req = getRequest(u.uid);

    return (
      <div style={{ margin: "0 16px 8px", background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: 14, padding: "13px 15px", display: "flex", alignItems: "center", gap: 13 }}>
        <Avatar initials={u.displayName.slice(0, 2).toUpperCase()} color={color} size={46} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <p style={{ fontSize: 14, fontWeight: 600, color: TEXT, margin: "0 0 2px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{u.displayName}</p>
          <p style={{ fontSize: 12, color: u.username ? "#a78bfa" : MUTED, margin: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{u.username ? `@${u.username}` : u.email}</p>
        </div>
        <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
          {status === "none" && (
            <>
              <button onClick={() => sendRequest(u)} disabled={isActing} style={{ background: GRAD, border: "none", borderRadius: 10, padding: "8px 13px", fontSize: 12, fontWeight: 600, color: "#fff", cursor: "pointer", fontFamily: font, boxShadow: "0 4px 12px rgba(124,58,237,0.3)", opacity: isActing ? 0.6 : 1 }}>
                {isActing ? "…" : "+ Add"}
              </button>
              <button onClick={() => onBlock(u.uid)} title="Block user" style={{ background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.15)", borderRadius: 10, padding: "8px 10px", fontSize: 12, color: "#fca5a5", cursor: "pointer", display: "flex", alignItems: "center", fontFamily: font }}>
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="12" r="10"/><path d="m4.9 4.9 14.2 14.2"/></svg>
              </button>
            </>
          )}
          {status === "outgoing_pending" && (
            <button onClick={() => cancelRequest(u)} disabled={isActing} style={{ background: FIELD_BG, border: `1px solid ${BORDER}`, borderRadius: 10, padding: "8px 13px", fontSize: 12, fontWeight: 600, color: MUTED, cursor: "pointer", fontFamily: font }}>
              {isActing ? "…" : "Pending"}
            </button>
          )}
          {status === "incoming_pending" && req && (
            <>
              <button onClick={() => respondRequest(req.id, true)} disabled={isActing} style={{ background: GRAD, border: "none", borderRadius: 10, padding: "8px 11px", fontSize: 12, fontWeight: 600, color: "#fff", cursor: "pointer", fontFamily: font, boxShadow: "0 4px 12px rgba(124,58,237,0.3)" }}>
                {isActing ? "…" : "Accept"}
              </button>
              <button onClick={() => respondRequest(req.id, false)} disabled={isActing} style={{ background: FIELD_BG, border: `1px solid ${BORDER}`, borderRadius: 10, padding: "8px 10px", fontSize: 12, fontWeight: 600, color: "#fca5a5", cursor: "pointer", fontFamily: font }}>
                ✕
              </button>
            </>
          )}
          {status === "friends" && (
            <>
              <button onClick={() => openFriendChat(u)} disabled={isActing} style={{ background: GRAD, border: "none", borderRadius: 10, padding: "8px 12px", fontSize: 12, fontWeight: 600, color: "#fff", cursor: "pointer", fontFamily: font, boxShadow: "0 4px 12px rgba(124,58,237,0.3)" }}>
                {isActing ? "…" : "Chat"}
              </button>
              <div style={{ background: "rgba(52,211,153,0.12)", border: "1px solid rgba(52,211,153,0.3)", borderRadius: 10, padding: "8px 10px", display: "flex", alignItems: "center" }}>
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#34d399" strokeWidth="2.5" strokeLinecap="round"><polyline points="20 6 9 17 4 12"/></svg>
              </div>
            </>
          )}
        </div>
      </div>
    );
  };

  const EmptyState = ({ icon, title, sub }: { icon: ReactNode; title: string; sub: string }) => (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "60px 32px", textAlign: "center" }}>
      <div style={{ width: 64, height: 64, borderRadius: 20, background: `${ACCENT}22`, border: `1.5px solid ${ACCENT}44`, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 16 }}>{icon}</div>
      <p style={{ fontSize: 15, fontWeight: 600, color: TEXT, margin: "0 0 6px" }}>{title}</p>
      <p style={{ fontSize: 13, color: MUTED, margin: 0 }}>{sub}</p>
    </div>
  );

  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
      <div style={{ padding: "18px 22px 14px", display: "flex", alignItems: "center", justifyContent: "space-between", flexShrink: 0 }}>
        <h2 style={{ fontSize: 20, fontWeight: 700, color: TEXT, margin: 0, letterSpacing: "-0.3px" }}>People</h2>
        {pendingIncoming.length > 0 && (
          <button onClick={() => setSubView("requests")} style={{ background: GRAD, border: "none", borderRadius: 10, padding: "6px 12px", fontSize: 12, fontWeight: 700, color: "#fff", cursor: "pointer", fontFamily: font, display: "flex", alignItems: "center", gap: 6, boxShadow: "0 4px 14px rgba(124,58,237,0.4)", animation: "pulse 2s ease-in-out infinite" }}>
            <div style={{ width: 7, height: 7, borderRadius: "50%", background: "#fff" }} />
            {pendingIncoming.length} new request{pendingIncoming.length > 1 ? "s" : ""}
          </button>
        )}
      </div>

      <SubNav />

      {fsError ? (
        <div style={{ margin: "0 22px", background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.2)", borderRadius: 14, padding: "16px 18px" }}>
          <p style={{ fontSize: 13, color: "#fca5a5", margin: 0, lineHeight: 1.6 }}>{fsError}</p>
        </div>
      ) : subView === "friends" ? (
        <div style={{ flex: 1, overflowY: "auto" }}>
          {friendUsers.length === 0
            ? <EmptyState icon={<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#a78bfa" strokeWidth="1.5" strokeLinecap="round"><circle cx="9" cy="7" r="4"/><path d="M3 21v-2a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v2"/><path d="M16 11l2 2 4-4"/></svg>} title="No friends yet" sub="Go to Discover and add people to your network!" />
            : friendUsers.map((u) => <UserCard key={u.uid} u={u} status="friends" />)
          }
        </div>
      ) : subView === "requests" ? (
        <div style={{ flex: 1, overflowY: "auto" }}>
          {pendingIncoming.length === 0 ? (
            <EmptyState icon={<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#a78bfa" strokeWidth="1.5" strokeLinecap="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>} title="No pending requests" sub="When someone adds you, their request will appear here." />
          ) : (
            <>
              <p style={{ fontSize: 12, color: MUTED, fontWeight: 600, margin: "0 22px 10px", textTransform: "uppercase", letterSpacing: "0.5px" }}>Incoming Requests</p>
              {pendingIncoming.map((req) => {
                const sender = users.find((u) => u.uid === req.from) ?? { uid: req.from, displayName: req.fromName, email: "" };
                return (
                  <div key={req.id} style={{ margin: "0 16px 8px", background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: 14, padding: "13px 15px", display: "flex", alignItems: "center", gap: 13 }}>
                    <Avatar initials={req.fromName.slice(0, 2).toUpperCase()} color={uidColor(req.from)} size={46} />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <p style={{ fontSize: 14, fontWeight: 600, color: TEXT, margin: "0 0 2px" }}>{req.fromName}</p>
                      <p style={{ fontSize: 12, color: MUTED, margin: 0 }}>{sender.email || "Wants to be friends"}</p>
                    </div>
                    <div style={{ display: "flex", gap: 6 }}>
                      <button onClick={() => respondRequest(req.id, true)} disabled={acting === req.id} style={{ background: GRAD, border: "none", borderRadius: 10, padding: "8px 12px", fontSize: 12, fontWeight: 600, color: "#fff", cursor: "pointer", fontFamily: font, boxShadow: "0 4px 12px rgba(124,58,237,0.3)" }}>
                        {acting === req.id ? "…" : "Accept"}
                      </button>
                      <button onClick={() => respondRequest(req.id, false)} disabled={acting === req.id} style={{ background: FIELD_BG, border: `1px solid ${BORDER}`, borderRadius: 10, padding: "8px 12px", fontSize: 12, fontWeight: 600, color: "#fca5a5", cursor: "pointer", fontFamily: font }}>
                        Reject
                      </button>
                    </div>
                  </div>
                );
              })}
              {outgoing.filter((r) => r.status === "pending").length > 0 && (
                <>
                  <p style={{ fontSize: 12, color: MUTED, fontWeight: 600, margin: "16px 22px 10px", textTransform: "uppercase", letterSpacing: "0.5px" }}>Sent Requests</p>
                  {outgoing.filter((r) => r.status === "pending").map((req) => (
                    <div key={req.id} style={{ margin: "0 16px 8px", background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: 14, padding: "13px 15px", display: "flex", alignItems: "center", gap: 13 }}>
                      <Avatar initials={req.toName.slice(0, 2).toUpperCase()} color={uidColor(req.to)} size={46} />
                      <div style={{ flex: 1 }}>
                        <p style={{ fontSize: 14, fontWeight: 600, color: TEXT, margin: "0 0 2px" }}>{req.toName}</p>
                        <p style={{ fontSize: 12, color: MUTED, margin: 0 }}>Request sent</p>
                      </div>
                      <button onClick={async () => { setActing(req.id); try { await deleteDoc(doc(db, "friendRequests", req.id)); } finally { setActing(null); } }} disabled={acting === req.id} style={{ background: FIELD_BG, border: `1px solid ${BORDER}`, borderRadius: 10, padding: "8px 12px", fontSize: 12, fontWeight: 600, color: MUTED, cursor: "pointer", fontFamily: font }}>
                        Cancel
                      </button>
                    </div>
                  ))}
                </>
              )}
            </>
          )}
        </div>
      ) : (
        <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
          <div style={{ margin: "0 22px 12px", position: "relative", flexShrink: 0 }}>
            <div style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)", color: MUTED, pointerEvents: "none" }}>
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
            </div>
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search by name or email…"
              style={{ width: "100%", background: FIELD_BG, border: `1.5px solid ${BORDER}`, borderRadius: 12, padding: "11px 16px 11px 38px", fontSize: 14, color: TEXT, outline: "none", boxSizing: "border-box", fontFamily: font }} />
          </div>
          <div style={{ flex: 1, overflowY: "auto" }}>
            {filtered.length === 0
              ? <EmptyState icon={<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#a78bfa" strokeWidth="1.5" strokeLinecap="round"><circle cx="10" cy="7" r="4"/><path d="M10.3 15H7a4 4 0 0 0-4 4v1"/><circle cx="17" cy="15" r="3"/><path d="M17 12v1m0 4v1m-2.5-2.5h1m4 0h1"/></svg>} title={search.trim() ? "No results" : "No other users yet"} sub={search.trim() ? "Try a different name or email" : "Invite friends to join Bondify!"} />
              : filtered.map((u) => <UserCard key={u.uid} u={u} status={getStatus(u.uid)} />)
            }
          </div>
        </div>
      )}
    </div>
  );
}

// ──────────────────────── Tab Bar ────────────────────────

function TabBar({ active, onChange, unreadChats, pendingRequests }: { active: Tab; onChange: (t: Tab) => void; unreadChats: number; pendingRequests: number }) {
  const tabs: { id: Tab; label: string; icon: ReactNode }[] = [
    {
      id: "home", label: "Home",
      icon: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>,
    },
    {
      id: "chats", label: "Chats",
      icon: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>,
    },
    {
      id: "people", label: "People",
      icon: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="9" cy="7" r="4"/><path d="M3 21v-2a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v2"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/><path d="M21 21v-2a4 4 0 0 0-3-3.85"/></svg>,
    },
    {
      id: "profile", label: "Profile",
      icon: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="8" r="4"/><path d="M20 21a8 8 0 1 0-16 0"/></svg>,
    },
  ];

  return (
    <div style={{ display: "flex", background: "rgba(12,12,26,0.95)", borderTop: `1px solid ${BORDER}`, backdropFilter: "blur(20px)", paddingBottom: 20 }}>
      {tabs.map((tab) => {
        const isActive = tab.id === active;
        return (
          <button key={tab.id} onClick={() => onChange(tab.id)} style={{ flex: 1, background: "none", border: "none", padding: "12px 0 6px", display: "flex", flexDirection: "column", alignItems: "center", gap: 4, cursor: "pointer", color: isActive ? "#a78bfa" : MUTED, transition: "color 0.2s", position: "relative" }}>
            {tab.id === "chats" && unreadChats > 0 && (
              <div style={{ position: "absolute", top: 8, right: "calc(50% - 14px)", width: 16, height: 16, borderRadius: "50%", background: GRAD, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 9, fontWeight: 700, color: "#fff" }}>{unreadChats}</div>
            )}
            {tab.id === "people" && pendingRequests > 0 && (
              <div style={{ position: "absolute", top: 8, right: "calc(50% - 14px)", width: 16, height: 16, borderRadius: "50%", background: "#ec4899", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 9, fontWeight: 700, color: "#fff" }}>{pendingRequests}</div>
            )}
            <div style={{ color: isActive ? "#a78bfa" : MUTED }}>{tab.icon}</div>
            <span style={{ fontSize: 10, fontWeight: isActive ? 700 : 500, letterSpacing: "0.3px" }}>{tab.label}</span>
            {isActive && <div style={{ position: "absolute", bottom: 0, width: 20, height: 2.5, borderRadius: 2, background: GRAD }} />}
          </button>
        );
      })}
    </div>
  );
}

// ──────────────────────── Home Tab ────────────────────────

function HomeTab({ user, onOpenChat, onSignOut }: { user: User; onOpenChat: (id: string, name: string, initials: string, color: string) => void; onSignOut: () => void }) {
  const [signingOut, setSigningOut] = useState(false);
  const displayName = user.displayName || user.email?.split("@")[0] || "there";
  const initials = displayName.slice(0, 2).toUpperCase();

  const handleSignOut = async () => {
    setSigningOut(true);
    await signOut(auth);
    setSigningOut(false);
    onSignOut();
  };

  return (
    <div style={{ flex: 1, overflowY: "auto" }}>
      <div style={{ padding: "16px 22px 0", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <p style={{ fontSize: 12, color: MUTED, margin: "0 0 2px" }}>Good morning,</p>
          <h2 style={{ fontSize: 20, fontWeight: 700, color: TEXT, margin: 0, letterSpacing: "-0.3px" }}>{displayName} 👋</h2>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <button style={{ background: FIELD_BG, border: `1.5px solid ${BORDER}`, borderRadius: 12, width: 40, height: 40, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", color: "#94a3b8" }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
          </button>
          <div style={{ width: 40, height: 40, borderRadius: 13, background: GRAD, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 15, fontWeight: 700, color: "#fff", boxShadow: "0 4px 14px rgba(124,58,237,0.35)" }}>{initials}</div>
        </div>
      </div>

      <div style={{ margin: "20px 22px 0", background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: 16, padding: "16px 18px", display: "flex", justifyContent: "space-between" }}>
        {[{ label: "Bonds", value: "24" }, { label: "Groups", value: "7" }, { label: "Events", value: "3" }].map((s, i) => (
          <div key={s.label} style={{ textAlign: "center", flex: 1, borderRight: i < 2 ? `1px solid ${BORDER}` : "none" }}>
            <p style={{ fontSize: 22, fontWeight: 800, color: TEXT, margin: 0, background: GRAD, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>{s.value}</p>
            <p style={{ fontSize: 12, color: MUTED, margin: "2px 0 0" }}>{s.label}</p>
          </div>
        ))}
      </div>

      <div style={{ margin: "20px 22px 0" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
          <h3 style={{ fontSize: 16, fontWeight: 700, color: TEXT, margin: 0 }}>Recent Bonds</h3>
          <button style={{ background: "none", border: "none", fontSize: 13, color: "#a78bfa", cursor: "pointer", padding: 0, fontWeight: 600, fontFamily: font }}>See all</button>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {DEMO_CONTACTS.map((b) => (
            <div key={b.id} style={{ background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: 14, padding: "13px 15px", display: "flex", alignItems: "center", gap: 13 }}>
              <Avatar initials={b.initials} color={b.color} />
              <div style={{ flex: 1 }}>
                <p style={{ fontSize: 14, fontWeight: 600, color: TEXT, margin: "0 0 2px" }}>{b.name}</p>
                <p style={{ fontSize: 12, color: MUTED, margin: 0 }}>{b.status}</p>
              </div>
              <button onClick={() => onOpenChat(b.id, b.name, b.initials, b.color)} style={{ background: `${ACCENT}22`, border: `1px solid ${ACCENT}44`, borderRadius: 10, padding: "7px 14px", fontSize: 12, fontWeight: 600, color: "#c4b5fd", cursor: "pointer", fontFamily: font }}>
                Chat
              </button>
            </div>
          ))}
        </div>
      </div>

      <div style={{ margin: "20px 22px 16px" }}>
        <Btn onClick={handleSignOut} loading={signingOut} secondary>Sign Out</Btn>
      </div>
    </div>
  );
}

// ──────────────────────── Chats Tab ────────────────────────

function ChatsTab({ user, onOpenChat }: { user: User; onOpenChat: (id: string, name: string, initials: string, color: string) => void }) {
  const [chats, setChats] = useState<ChatRoom[]>([]);
  const [fsError, setFsError] = useState("");

  useEffect(() => {
    setFsError("");
    const q = query(collection(db, "chats"), orderBy("lastMessageAt", "desc"));
    const unsub = onSnapshot(q, (snap) => {
      const rooms: ChatRoom[] = [];
      snap.forEach((d) => {
        const data = d.data();
        if (!data.participants?.includes(user.uid)) return;
        const otherId = data.participants.find((p: string) => p !== user.uid) ?? "";
        const otherName = data.participantNames?.[otherId] ?? "Unknown";
        const contact = DEMO_CONTACTS.find((c) => c.id === otherId);
        rooms.push({
          id: d.id,
          otherName,
          otherInitials: otherName.slice(0, 2).toUpperCase(),
          otherColor: contact?.color ?? "#6366f1",
          lastMessage: data.lastMessage ?? "",
          lastMessageAt: data.lastMessageAt ?? null,
        });
      });
      setChats(rooms);
    }, (err) => {
      if (err.code === "permission-denied") {
        setFsError("Firestore not enabled yet. Enable it in your Firebase Console and set security rules.");
      } else {
        setFsError(`Firestore error: ${err.message}`);
      }
    });
    return unsub;
  }, [user.uid]);

  const formatTime = (ts: Timestamp | null) => {
    if (!ts) return "";
    const d = ts.toDate();
    const now = new Date();
    const diff = now.getTime() - d.getTime();
    if (diff < 60000) return "Just now";
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    return d.toLocaleDateString([], { month: "short", day: "numeric" });
  };

  return (
    <div style={{ flex: 1, overflowY: "auto" }}>
      <div style={{ padding: "18px 22px 14px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <h2 style={{ fontSize: 20, fontWeight: 700, color: TEXT, margin: 0, letterSpacing: "-0.3px" }}>Messages</h2>
        <button style={{ background: `${ACCENT}22`, border: `1px solid ${ACCENT}44`, borderRadius: 10, padding: "7px 14px", fontSize: 12, fontWeight: 600, color: "#c4b5fd", cursor: "pointer", fontFamily: font }}>+ New Chat</button>
      </div>

      {/* Search bar */}
      <div style={{ margin: "0 22px 16px", position: "relative" }}>
        <div style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)", color: MUTED }}>
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
        </div>
        <input placeholder="Search messages…" style={{ width: "100%", background: FIELD_BG, border: `1.5px solid ${BORDER}`, borderRadius: 12, padding: "11px 16px 11px 38px", fontSize: 14, color: TEXT, outline: "none", boxSizing: "border-box", fontFamily: font }} />
      </div>

      {fsError ? (
        <div style={{ margin: "16px 22px", background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.2)", borderRadius: 14, padding: "16px 18px" }}>
          <p style={{ fontSize: 13, color: "#fca5a5", margin: 0, lineHeight: 1.6 }}>{fsError}</p>
        </div>
      ) : chats.length === 0 ? (
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "60px 32px", textAlign: "center" }}>
          <div style={{ width: 64, height: 64, borderRadius: 20, background: `${ACCENT}22`, border: `1.5px solid ${ACCENT}44`, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 16 }}>
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#a78bfa" strokeWidth="1.5" strokeLinecap="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
          </div>
          <p style={{ fontSize: 15, fontWeight: 600, color: TEXT, margin: "0 0 6px" }}>No messages yet</p>
          <p style={{ fontSize: 13, color: MUTED, margin: 0 }}>Go to Home and tap Chat to start a conversation</p>
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column" }}>
          {chats.map((chat) => (
            <button key={chat.id} onClick={() => onOpenChat(chat.id, chat.otherName, chat.otherInitials, chat.otherColor)} style={{ background: "none", border: "none", padding: "12px 22px", display: "flex", alignItems: "center", gap: 14, cursor: "pointer", textAlign: "left", borderBottom: `1px solid ${BORDER}` }}>
              <Avatar initials={chat.otherInitials} color={chat.otherColor} size={48} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 3 }}>
                  <p style={{ fontSize: 14, fontWeight: 600, color: TEXT, margin: 0 }}>{chat.otherName}</p>
                  <span style={{ fontSize: 11, color: MUTED, flexShrink: 0 }}>{formatTime(chat.lastMessageAt)}</span>
                </div>
                <p style={{ fontSize: 13, color: MUTED, margin: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{chat.lastMessage || "No messages yet"}</p>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

// ──────────────────────── Chat Room Screen ────────────────────────

function ChatRoomScreen({ user, chatId, otherName, otherInitials, otherColor, onBack }: {
  user: User; chatId: string; otherName: string; otherInitials: string; otherColor: string; onBack: () => void;
}) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const [fsError, setFsError] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);
  const displayName = user.displayName || user.email?.split("@")[0] || "Me";

  // Ensure chat document exists
  useEffect(() => {
    const chatRef = doc(db, "chats", chatId);
    getDoc(chatRef).then((snap) => {
      if (!snap.exists()) {
        setDoc(chatRef, {
          participants: [user.uid, chatId],
          participantNames: { [user.uid]: displayName, [chatId]: otherName },
          lastMessage: "",
          lastMessageAt: serverTimestamp(),
          createdAt: serverTimestamp(),
        });
      }
    });
  }, [chatId, user.uid, displayName, otherName]);

  // Listen to messages in real-time
  useEffect(() => {
    setFsError("");
    const q = query(collection(db, "chats", chatId, "messages"), orderBy("createdAt", "asc"));
    const unsub = onSnapshot(q, (snap) => {
      setMessages(snap.docs.map((d) => ({ id: d.id, ...d.data() } as ChatMessage)));
    }, (err) => {
      if (err.code === "permission-denied") {
        setFsError("Firestore not set up yet. Enable it in Firebase Console with the security rules from the setup guide.");
      } else {
        setFsError(`Could not load messages: ${err.message}`);
      }
    });
    return unsub;
  }, [chatId]);

  // Auto-scroll to latest message
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = async () => {
    const trimmed = text.trim();
    if (!trimmed || sending) return;
    setSending(true);
    setText("");
    try {
      const chatRef = doc(db, "chats", chatId);
      await addDoc(collection(db, "chats", chatId, "messages"), {
        text: trimmed,
        senderId: user.uid,
        senderName: displayName,
        createdAt: serverTimestamp(),
      });
      await setDoc(chatRef, { lastMessage: trimmed, lastMessageAt: serverTimestamp() }, { merge: true });
    } finally {
      setSending(false);
    }
  };

  const formatMsgTime = (ts: Timestamp | null) => {
    if (!ts) return "";
    return ts.toDate().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };

  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", animation: "slideUp 0.25s ease" }}>
      {/* Header */}
      <div style={{ padding: "14px 16px", display: "flex", alignItems: "center", gap: 12, borderBottom: `1px solid ${BORDER}`, background: "rgba(12,12,26,0.8)", backdropFilter: "blur(12px)" }}>
        <button onClick={onBack} style={{ background: "none", border: "none", cursor: "pointer", color: "#a78bfa", padding: "4px", display: "flex", alignItems: "center" }}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M15 18l-6-6 6-6"/></svg>
        </button>
        <Avatar initials={otherInitials} color={otherColor} size={38} />
        <div style={{ flex: 1 }}>
          <p style={{ fontSize: 15, fontWeight: 700, color: TEXT, margin: "0 0 1px" }}>{otherName}</p>
          <p style={{ fontSize: 11, color: "#34d399", margin: 0, display: "flex", alignItems: "center", gap: 4 }}>
            <span style={{ width: 6, height: 6, borderRadius: "50%", background: "#34d399", display: "inline-block" }} />
            Active now
          </p>
        </div>
        <button style={{ background: FIELD_BG, border: `1.5px solid ${BORDER}`, borderRadius: 10, width: 36, height: 36, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", color: "#94a3b8" }}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 11.5 19.79 19.79 0 0 1 1.62 2.84 2 2 0 0 1 3.6 0.65h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.27a16 16 0 0 0 6 6l.94-.94a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 21.73 16"/></svg>
        </button>
      </div>

      {/* Messages */}
      <div style={{ flex: 1, overflowY: "auto", padding: "16px 16px 8px", display: "flex", flexDirection: "column", gap: 8 }}>
        {fsError && (
          <div style={{ background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.2)", borderRadius: 14, padding: "14px 16px", margin: "4px 0 8px" }}>
            <p style={{ fontSize: 13, color: "#fca5a5", margin: 0, lineHeight: 1.6 }}>{fsError}</p>
          </div>
        )}
        {!fsError && messages.length === 0 && (
          <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", textAlign: "center" }}>
            <div>
              <Avatar initials={otherInitials} color={otherColor} size={56} />
              <p style={{ fontSize: 15, fontWeight: 600, color: TEXT, marginTop: 12, marginBottom: 4 }}>{otherName}</p>
              <p style={{ fontSize: 13, color: MUTED }}>Say hello to start the conversation!</p>
            </div>
          </div>
        )}
        {!fsError && messages.map((msg) => {
          const isMe = msg.senderId === user.uid;
          return (
            <div key={msg.id} style={{ display: "flex", flexDirection: "column", alignItems: isMe ? "flex-end" : "flex-start", animation: "msgIn 0.2s ease" }}>
              <div style={{
                maxWidth: "75%", padding: "10px 14px", borderRadius: isMe ? "18px 18px 4px 18px" : "18px 18px 18px 4px",
                background: isMe ? GRAD : "rgba(255,255,255,0.07)",
                boxShadow: isMe ? "0 4px 16px rgba(124,58,237,0.3)" : "none",
                border: isMe ? "none" : `1px solid ${BORDER}`,
              }}>
                <p style={{ fontSize: 14, color: "#fff", margin: 0, lineHeight: 1.5, wordBreak: "break-word" }}>{msg.text}</p>
              </div>
              <span style={{ fontSize: 10, color: MUTED, marginTop: 3, paddingLeft: isMe ? 0 : 4, paddingRight: isMe ? 4 : 0 }}>{formatMsgTime(msg.createdAt)}</span>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div style={{ padding: "10px 14px 24px", borderTop: `1px solid ${BORDER}`, display: "flex", gap: 10, alignItems: "center", background: "rgba(12,12,26,0.9)", backdropFilter: "blur(12px)" }}>
        <div style={{ flex: 1, background: FIELD_BG, border: `1.5px solid ${BORDER}`, borderRadius: 22, display: "flex", alignItems: "center", padding: "10px 16px", gap: 8 }}>
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } }}
            placeholder="Type a message…"
            style={{ flex: 1, background: "none", border: "none", outline: "none", fontSize: 14, color: TEXT, fontFamily: font }}
          />
          <button style={{ background: "none", border: "none", cursor: "pointer", color: MUTED, padding: 0, display: "flex" }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg>
          </button>
        </div>
        <button onClick={sendMessage} disabled={!text.trim() || sending} style={{
          width: 44, height: 44, borderRadius: "50%", background: text.trim() ? GRAD : FIELD_BG,
          border: text.trim() ? "none" : `1.5px solid ${BORDER}`, display: "flex", alignItems: "center", justifyContent: "center",
          cursor: text.trim() ? "pointer" : "default", boxShadow: text.trim() ? "0 4px 16px rgba(124,58,237,0.4)" : "none",
          transition: "all 0.2s", flexShrink: 0,
        }}>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={text.trim() ? "#fff" : MUTED} strokeWidth="2.5" strokeLinecap="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
        </button>
      </div>
    </div>
  );
}

// ──────────────────────── App Screen (tabbed) ────────────────────────

function AppScreen({ user, onSignOut, onOpenChat }: {
  user: User; onSignOut: () => void;
  onOpenChat: (id: string, name: string, initials: string, color: string) => void;
}) {
  const [tab, setTab] = useState<Tab>("home");
  const [unreadChats, setUnreadChats] = useState(0);
  const [pendingRequests, setPendingRequests] = useState(0);
  const [blockedUsers, setBlockedUsers] = useState<string[]>([]);

  useEffect(() => {
    const q = query(collection(db, "chats"), orderBy("lastMessageAt", "desc"));
    return onSnapshot(q, (snap) => {
      setUnreadChats(snap.docs.filter((d) => {
        const data = d.data();
        return data.participants?.includes(user.uid) && data.lastMessage;
      }).length);
    });
  }, [user.uid]);

  useEffect(() => {
    return onSnapshot(doc(db, "users", user.uid), (snap) => {
      if (snap.exists()) setBlockedUsers(snap.data().blockedUsers ?? []);
    });
  }, [user.uid]);

  const handleBlock = (uid: string) =>
    updateDoc(doc(db, "users", user.uid), { blockedUsers: arrayUnion(uid) }).catch(() => {
      setDoc(doc(db, "users", user.uid), { blockedUsers: [uid] }, { merge: true });
    });

  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
      {tab === "home"
        ? <HomeTab user={user} onOpenChat={onOpenChat} onSignOut={onSignOut} />
        : tab === "chats"
        ? <ChatsTab user={user} onOpenChat={onOpenChat} />
        : tab === "people"
        ? <FindFriendsScreen currentUser={user} onOpenChat={onOpenChat} onPendingCount={setPendingRequests} blockedUsers={blockedUsers} onBlock={handleBlock} />
        : <ProfileTab user={user} onSignOut={onSignOut} />}
      <TabBar active={tab} onChange={setTab} unreadChats={tab === "chats" ? 0 : unreadChats} pendingRequests={tab === "people" ? 0 : pendingRequests} />
    </div>
  );
}

// ──────────────────────── Setup Screen ────────────────────────

function SetupScreen() {
  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "32px 28px", textAlign: "center" }}>
      <div style={{ width: 64, height: 64, borderRadius: 20, background: "rgba(251,191,36,0.12)", border: "1.5px solid rgba(251,191,36,0.3)", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 20 }}>
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#fbbf24" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
      </div>
      <h2 style={{ fontSize: 20, fontWeight: 700, color: TEXT, margin: "0 0 10px" }}>Firebase Setup Required</h2>
      <p style={{ fontSize: 14, color: MUTED, margin: "0 0 24px", lineHeight: 1.6 }}>Add your Firebase credentials to enable authentication.</p>
      <div style={{ background: "rgba(124,58,237,0.08)", border: `1px solid ${ACCENT}33`, borderRadius: 14, padding: "16px 18px", textAlign: "left", width: "100%" }}>
        {["VITE_FIREBASE_API_KEY", "VITE_FIREBASE_AUTH_DOMAIN", "VITE_FIREBASE_PROJECT_ID", "VITE_FIREBASE_APP_ID"].map((v) => (
          <p key={v} style={{ fontSize: 12, color: "#c4b5fd", margin: "0 0 4px", fontFamily: "monospace" }}>{v}</p>
        ))}
      </div>
    </div>
  );
}

// ──────────────────────── Root App ────────────────────────

export function BondifyApp() {
  const [screen, setScreen] = useState<Screen>("splash");
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [splashDone, setSplashDone] = useState(false);
  const [chatTarget, setChatTarget] = useState<{ id: string; name: string; initials: string; color: string } | null>(null);

  useEffect(() => {
    if (!isFirebaseConfigured) { setAuthLoading(false); return; }
    return onAuthStateChanged(auth, (u) => { setUser(u); setAuthLoading(false); });
  }, []);

  const handleSplashDone = () => setSplashDone(true);

  const routeUser = async (u: User) => {
    try {
      const snap = await getDoc(doc(db, "users", u.uid));
      const uname = snap.exists() ? (snap.data().username ?? "") : "";
      setScreen(uname.trim() ? "app" : "username_setup");
    } catch { setScreen("app"); }
  };

  useEffect(() => {
    if (splashDone && !authLoading) {
      if (user) routeUser(user);
      else setScreen("login");
    }
  }, [splashDone, authLoading, user]);

  useEffect(() => {
    if (!authLoading && !user && screen !== "splash") setScreen("login");
  }, [user, authLoading]);

  const openChat = (id: string, name: string, initials: string, color: string) => {
    setChatTarget({ id, name, initials, color });
    setScreen("chatroom");
  };

  const containerStyle: CSSProperties = {
    width: "100%", minHeight: "100dvh", maxWidth: 390, margin: "0 auto",
    background: BG, fontFamily: font, display: "flex", flexDirection: "column",
    position: "relative", overflow: "hidden",
  };

  return (
    <div style={containerStyle}>
      <Glow top={-80} left={-60} color="rgba(124,58,237,0.16)" />
      <Glow top={100} right={-80} color="rgba(168,85,247,0.1)" />

      {screen === "splash" ? (
        <SplashScreen onDone={handleSplashDone} />
      ) : (
        <>
          {screen !== "chatroom" && <StatusBar />}
          {!isFirebaseConfigured ? <SetupScreen />
            : screen === "chatroom" && chatTarget && user ? (
              <ChatRoomScreen user={user} chatId={chatTarget.id} otherName={chatTarget.name} otherInitials={chatTarget.initials} otherColor={chatTarget.color} onBack={() => { setScreen("app"); setChatTarget(null); }} />
            ) : screen === "signup" ? (
              <SignupScreen onNavigate={setScreen} />
            ) : screen === "username_setup" && user ? (
              <UsernameSetupScreen user={user} onComplete={() => setScreen("app")} />
            ) : screen === "app" && user ? (
              <AppScreen user={user} onSignOut={() => setScreen("login")} onOpenChat={openChat} />
            ) : (
              <LoginScreen onNavigate={setScreen} />
            )}
        </>
      )}
    </div>
  );
}

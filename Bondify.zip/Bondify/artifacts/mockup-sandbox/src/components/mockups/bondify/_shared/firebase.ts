import { initializeApp, getApps } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyCn5uQ1wSd-5Rh9pUdNvG2Wi1kgQy_GBQM",
  authDomain: "bondify-041s.firebaseapp.com",
  databaseURL: "https://bondify-041s-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "bondify-041s",
  storageBucket: "bondify-041s.firebasestorage.app",
  messagingSenderId: "626890155558",
  appId: "1:626890155558:web:b5a41c2177b1c1b46fa8e7",
  measurementId: "G-XE2QBZRS56",
};

export const isFirebaseConfigured = true;

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];

export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

import { useState, useEffect, useRef, type ReactNode } from "react";
import { type User, signOut } from "firebase/auth";
import {
  doc, setDoc, getDoc, onSnapshot, serverTimestamp,
  collection, query, where, Timestamp, arrayRemove, updateDoc, deleteDoc,
} from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { auth, db, storage } from "./_shared/firebase";

const CARD_BG = "rgba(255,255,255,0.03)";
const BORDER = "rgba(255,255,255,0.07)";
const ACCENT = "#7c3aed";
const ACCENT2 = "#a855f7";
const GRAD = `linear-gradient(135deg, ${ACCENT} 0%, ${ACCENT2} 100%)`;
const TEXT = "#f1f5f9";
const MUTED = "#64748b";
const FIELD_BG = "rgba(255,255,255,0.04)";
const FIELD_FOCUS_BG = "rgba(124,58,237,0.09)";
const FIELD_FOCUS_BORDER = "rgba(124,58,237,0.65)";
const FIELD_BORDER = "rgba(255,255,255,0.08)";
const font = "'Inter', sans-serif";

export interface ProfileData {
  displayName: string;
  username: string;
  bio: string;
  phone: string;
  dob: string;
  gender: string;
  country: string;
  city: string;
  photoURL: string;
  email: string;
  privacy: { showEmail: boolean; showPhone: boolean; visibility: "public" | "friends" | "private" };
  createdAt: Timestamp | null;
  online: boolean;
  lastSeen: Timestamp | null;
  blockedUsers: string[];
}

// ──────────────────────── Shared UI ────────────────────────

function Toggle({ value, onChange }: { value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button onClick={() => onChange(!value)} style={{
      width: 44, height: 24, borderRadius: 12,
      background: value ? GRAD : "rgba(255,255,255,0.1)",
      border: "none", cursor: "pointer", position: "relative",
      transition: "background 0.2s", flexShrink: 0,
      boxShadow: value ? "0 2px 8px rgba(124,58,237,0.4)" : "none",
    }}>
      <div style={{
        position: "absolute", top: 3, left: value ? 23 : 3,
        width: 18, height: 18, borderRadius: "50%", background: "#fff",
        transition: "left 0.2s", boxShadow: "0 1px 4px rgba(0,0,0,0.3)",
      }} />
    </button>
  );
}

function SettingRow({ label, sub, right, onClick, danger }: { label: string; sub?: string; right?: ReactNode; onClick?: () => void; danger?: boolean }) {
  return (
    <div onClick={onClick} style={{ display: "flex", alignItems: "center", padding: "13px 18px", cursor: onClick ? "pointer" : "default", borderBottom: `1px solid ${BORDER}` }}>
      <div style={{ flex: 1 }}>
        <p style={{ fontSize: 14, color: danger ? "#fca5a5" : TEXT, margin: 0, fontWeight: 500 }}>{label}</p>
        {sub && <p style={{ fontSize: 12, color: MUTED, margin: "2px 0 0" }}>{sub}</p>}
      </div>
      {right ?? (onClick && <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={MUTED} strokeWidth="2" strokeLinecap="round"><path d="M9 18l6-6-6-6"/></svg>)}
    </div>
  );
}

function SectionCard({ title, children }: { title: string; children: ReactNode }) {
  return (
    <div style={{ margin: "0 16px 12px" }}>
      <p style={{ fontSize: 11, color: MUTED, fontWeight: 600, margin: "0 2px 6px", textTransform: "uppercase", letterSpacing: "0.5px" }}>{title}</p>
      <div style={{ background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: 14, overflow: "hidden" }}>{children}</div>
    </div>
  );
}

function FormField({ label, value, onChange, placeholder, type = "text", multiline }: {
  label: string; value: string; onChange: (v: string) => void;
  placeholder?: string; type?: string; multiline?: boolean;
}) {
  const [focused, setFocused] = useState(false);
  const style = {
    width: "100%", background: focused ? FIELD_FOCUS_BG : FIELD_BG,
    border: `1.5px solid ${focused ? FIELD_FOCUS_BORDER : FIELD_BORDER}`,
    borderRadius: 12, padding: "12px 14px", fontSize: 14, color: TEXT,
    outline: "none", boxSizing: "border-box" as const, fontFamily: font,
    resize: "none" as const, transition: "all 0.2s",
    boxShadow: focused ? "0 0 0 3px rgba(124,58,237,0.13)" : "none",
  };
  return (
    <div style={{ marginBottom: 12 }}>
      <p style={{ fontSize: 11, color: MUTED, fontWeight: 600, margin: "0 0 6px", textTransform: "uppercase", letterSpacing: "0.4px" }}>{label}</p>
      {multiline
        ? <textarea value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} onFocus={() => setFocused(true)} onBlur={() => setFocused(false)} rows={3} style={style} />
        : <input type={type} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} onFocus={() => setFocused(true)} onBlur={() => setFocused(false)} style={style} />
      }
    </div>
  );
}

// ──────────────────────── Edit Profile View ────────────────────────

function EditProfileView({ user, profile, onBack }: { user: User; profile: ProfileData; onBack: () => void }) {
  const [form, setForm] = useState({
    displayName: profile.displayName,
    username: profile.username,
    bio: profile.bio,
    phone: profile.phone,
    dob: profile.dob,
    gender: profile.gender,
    country: profile.country,
    city: profile.city,
  });
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [uploadError, setUploadError] = useState("");
  const [unameAvail, setUnameAvail] = useState<"idle" | "checking" | "available" | "taken" | "self" | "invalid">("idle");
  const unameTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const UNAME_RE = /^[a-zA-Z0-9_]{3,20}$/;

  const set = (key: string) => (v: string) => setForm((f) => ({ ...f, [key]: v }));

  const handleUsernameChange = (raw: string) => {
    const v = raw.replace(/[^a-zA-Z0-9_]/g, "").toLowerCase().slice(0, 20);
    setForm((f) => ({ ...f, username: v }));
    if (unameTimer.current) clearTimeout(unameTimer.current);
    if (!v) { setUnameAvail("idle"); return; }
    if (v === profile.username) { setUnameAvail("self"); return; }
    if (!UNAME_RE.test(v)) { setUnameAvail("invalid"); return; }
    setUnameAvail("checking");
    unameTimer.current = setTimeout(async () => {
      try {
        const snap = await getDoc(doc(db, "usernames", v));
        setUnameAvail(snap.exists() && snap.data().uid !== user.uid ? "taken" : "available");
      } catch { setUnameAvail("available"); }
    }, 500);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) { setUploadError("Image must be under 5MB"); return; }
    setUploadError("");
    setPhotoPreview(URL.createObjectURL(file));
    setPhotoFile(file);
  };

  const handleSave = async () => {
    if (unameAvail === "taken" || unameAvail === "invalid") return;
    if (unameAvail === "checking") return;
    setSaving(true);
    setUploadError("");
    try {
      let photoURL = profile.photoURL;
      if (photoFile) {
        try {
          const storageRef = ref(storage, `profilePhotos/${user.uid}`);
          await uploadBytes(storageRef, photoFile);
          photoURL = await getDownloadURL(storageRef);
        } catch {
          setUploadError("Photo upload failed — enable Firebase Storage in your console.");
        }
      }
      const username = form.username.replace(/[^a-zA-Z0-9_]/g, "").toLowerCase();
      // Update usernames reservation if changed
      if (username !== profile.username) {
        if (profile.username) {
          await deleteDoc(doc(db, "usernames", profile.username)).catch(() => {});
        }
        if (username) {
          await setDoc(doc(db, "usernames", username), { uid: user.uid });
        }
      }
      await setDoc(doc(db, "users", user.uid), { ...form, username, photoURL }, { merge: true });
      setSaved(true);
      setTimeout(() => { setSaved(false); onBack(); }, 1000);
    } finally {
      setSaving(false);
    }
  };

  const currentPhoto = photoPreview ?? (profile.photoURL || null);
  const initials = (form.displayName || user.email || "?").slice(0, 2).toUpperCase();

  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
      <div style={{ padding: "16px 20px 12px", display: "flex", alignItems: "center", gap: 12, borderBottom: `1px solid ${BORDER}`, flexShrink: 0, background: "rgba(12,12,26,0.9)" }}>
        <button onClick={onBack} style={{ background: "none", border: "none", cursor: "pointer", color: "#a78bfa", display: "flex", padding: 4 }}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M15 18l-6-6 6-6"/></svg>
        </button>
        <h2 style={{ fontSize: 18, fontWeight: 700, color: TEXT, margin: 0, flex: 1 }}>Edit Profile</h2>
        {saved && <span style={{ fontSize: 13, color: "#34d399", fontWeight: 700 }}>✓ Saved</span>}
      </div>

      <div style={{ flex: 1, overflowY: "auto", padding: "20px 20px 32px" }}>
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", marginBottom: 24 }}>
          <div onClick={() => fileRef.current?.click()} style={{ width: 90, height: 90, borderRadius: 28, overflow: "hidden", cursor: "pointer", background: `linear-gradient(135deg, ${ACCENT}99, ${ACCENT2}44)`, border: `2px solid ${ACCENT}55`, position: "relative", boxShadow: "0 8px 24px rgba(124,58,237,0.35)" }}>
            {currentPhoto
              ? <img src={currentPhoto} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              : <div style={{ width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 28, fontWeight: 700, color: "#fff" }}>{initials}</div>
            }
            <div style={{ position: "absolute", inset: 0, background: "rgba(0,0,0,0.38)", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>
            </div>
          </div>
          <button onClick={() => fileRef.current?.click()} style={{ marginTop: 10, background: "none", border: "none", fontSize: 13, color: "#a78bfa", cursor: "pointer", fontWeight: 600, fontFamily: font }}>
            {photoFile ? "Photo selected ✓" : "Change Photo"}
          </button>
          {uploadError && <p style={{ fontSize: 12, color: "#fca5a5", margin: "6px 0 0", textAlign: "center", lineHeight: 1.4 }}>{uploadError}</p>}
          <input ref={fileRef} type="file" accept="image/*" onChange={handleFileChange} style={{ display: "none" }} />
        </div>

        <FormField label="Full Name" value={form.displayName} onChange={set("displayName")} placeholder="Your full name" />
        {/* Username with live availability check */}
        <div style={{ marginBottom: 12 }}>
          <p style={{ fontSize: 11, color: MUTED, fontWeight: 600, margin: "0 0 6px", textTransform: "uppercase", letterSpacing: "0.4px" }}>Username</p>
          <div style={{ display: "flex", alignItems: "center", background: FIELD_BG, border: `1.5px solid ${unameAvail === "available" ? "rgba(52,211,153,0.55)" : unameAvail === "taken" || unameAvail === "invalid" ? "rgba(239,68,68,0.45)" : FIELD_BORDER}`, borderRadius: 12, overflow: "hidden", transition: "all 0.2s" }}>
            <span style={{ padding: "12px 2px 12px 14px", fontSize: 15, fontWeight: 600, color: ACCENT2, flexShrink: 0 }}>@</span>
            <input
              value={form.username}
              onChange={(e) => handleUsernameChange(e.target.value)}
              placeholder="yourname"
              style={{ flex: 1, background: "none", border: "none", outline: "none", fontSize: 14, color: TEXT, padding: "12px 10px 12px 2px", fontFamily: font }}
            />
            <div style={{ paddingRight: 12, fontSize: 12, fontWeight: 600, color: unameAvail === "available" ? "#34d399" : unameAvail === "taken" || unameAvail === "invalid" ? "#fca5a5" : unameAvail === "self" ? "#a78bfa" : MUTED, whiteSpace: "nowrap" as const, flexShrink: 0 }}>
              {unameAvail === "checking" && <div style={{ width: 13, height: 13, borderRadius: "50%", border: `2px solid rgba(255,255,255,0.1)`, borderTopColor: ACCENT, animation: "spin 0.7s linear infinite" }} />}
              {unameAvail === "available" && "✓"}
              {unameAvail === "taken" && "✗ Taken"}
              {unameAvail === "invalid" && "✗ Invalid"}
              {unameAvail === "self" && "✓ Current"}
            </div>
          </div>
          {unameAvail === "taken" && <p style={{ fontSize: 12, color: "#fca5a5", margin: "5px 0 0" }}>This username is already taken</p>}
          {unameAvail === "invalid" && <p style={{ fontSize: 12, color: "#fca5a5", margin: "5px 0 0" }}>3–20 characters, letters, numbers and _ only</p>}
        </div>
        <FormField label="Bio" value={form.bio} onChange={set("bio")} placeholder="Tell people about yourself…" multiline />
        <FormField label="Date of Birth" value={form.dob} onChange={set("dob")} placeholder="" type="date" />

        <div style={{ marginBottom: 12 }}>
          <p style={{ fontSize: 11, color: MUTED, fontWeight: 600, margin: "0 0 8px", textTransform: "uppercase", letterSpacing: "0.4px" }}>Gender</p>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            {["Male", "Female", "Non-binary", "Prefer not to say"].map((g) => (
              <button key={g} onClick={() => set("gender")(form.gender === g ? "" : g)} style={{
                background: form.gender === g ? GRAD : FIELD_BG,
                border: `1px solid ${form.gender === g ? "transparent" : BORDER}`,
                borderRadius: 10, padding: "8px 12px", fontSize: 12, fontWeight: 600,
                color: form.gender === g ? "#fff" : MUTED, cursor: "pointer", fontFamily: font,
                boxShadow: form.gender === g ? "0 2px 8px rgba(124,58,237,0.3)" : "none", transition: "all 0.2s",
              }}>{g}</button>
            ))}
          </div>
        </div>

        <FormField label="Country" value={form.country} onChange={set("country")} placeholder="e.g. United States" />
        <FormField label="City" value={form.city} onChange={set("city")} placeholder="e.g. New York" />
        <FormField label="Phone Number" value={form.phone} onChange={set("phone")} placeholder="+1 234 567 8900" type="tel" />

        <div style={{ marginTop: 8 }}>
          <button onClick={handleSave} disabled={saving || saved} style={{
            width: "100%", background: saving ? "rgba(124,58,237,0.4)" : saved ? "rgba(52,211,153,0.2)" : GRAD,
            border: saved ? "1px solid rgba(52,211,153,0.4)" : "none",
            borderRadius: 13, padding: "16px", fontSize: 15, fontWeight: 700,
            color: saved ? "#34d399" : "#fff", cursor: saving ? "default" : "pointer",
            boxShadow: saving || saved ? "none" : "0 6px 24px rgba(124,58,237,0.38)", fontFamily: font, transition: "all 0.3s",
          }}>
            {saving ? "Saving…" : saved ? "✓ Saved!" : "Save Changes"}
          </button>
        </div>
      </div>
    </div>
  );
}

// ──────────────────────── Blocked Users View ────────────────────────

function BlockedUsersView({ profile, userId, onBack }: { profile: ProfileData; userId: string; onBack: () => void }) {
  const [unblocking, setUnblocking] = useState<string | null>(null);

  const handleUnblock = async (uid: string) => {
    setUnblocking(uid);
    try { await updateDoc(doc(db, "users", userId), { blockedUsers: arrayRemove(uid) }); }
    finally { setUnblocking(null); }
  };

  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", overflowY: "auto" }}>
      <div style={{ padding: "16px 20px 12px", display: "flex", alignItems: "center", gap: 12, borderBottom: `1px solid ${BORDER}`, flexShrink: 0 }}>
        <button onClick={onBack} style={{ background: "none", border: "none", cursor: "pointer", color: "#a78bfa", display: "flex", padding: 4 }}>
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M15 18l-6-6 6-6"/></svg>
        </button>
        <h2 style={{ fontSize: 18, fontWeight: 700, color: TEXT, margin: 0 }}>Blocked Users</h2>
        <span style={{ marginLeft: "auto", fontSize: 12, color: MUTED, background: "rgba(255,255,255,0.05)", border: `1px solid ${BORDER}`, borderRadius: 8, padding: "3px 10px" }}>{profile.blockedUsers.length}</span>
      </div>
      {profile.blockedUsers.length === 0 ? (
        <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "60px 32px", textAlign: "center" }}>
          <div style={{ width: 60, height: 60, borderRadius: 20, background: "rgba(124,58,237,0.12)", border: `1.5px solid ${ACCENT}44`, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 14 }}>
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#a78bfa" strokeWidth="1.5" strokeLinecap="round"><circle cx="12" cy="12" r="10"/><path d="m4.9 4.9 14.2 14.2"/></svg>
          </div>
          <p style={{ fontSize: 15, fontWeight: 600, color: TEXT, margin: "0 0 6px" }}>No blocked users</p>
          <p style={{ fontSize: 13, color: MUTED, margin: 0 }}>Users you block won't appear in your feed</p>
        </div>
      ) : profile.blockedUsers.map((uid) => (
        <div key={uid} style={{ margin: "8px 16px 0", background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: 14, padding: "13px 15px", display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 44, height: 44, borderRadius: 14, background: "rgba(239,68,68,0.12)", border: "1px solid rgba(239,68,68,0.2)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14, color: "#fca5a5", fontWeight: 700, flexShrink: 0 }}>
            {uid.slice(0, 2).toUpperCase()}
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <p style={{ fontSize: 14, color: TEXT, margin: "0 0 2px", fontWeight: 500 }}>Blocked user</p>
            <p style={{ fontSize: 11, color: MUTED, margin: 0, fontFamily: "monospace", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{uid}</p>
          </div>
          <button onClick={() => handleUnblock(uid)} disabled={unblocking === uid} style={{ background: "rgba(52,211,153,0.1)", border: "1px solid rgba(52,211,153,0.3)", borderRadius: 10, padding: "7px 12px", fontSize: 12, fontWeight: 600, color: "#34d399", cursor: "pointer", fontFamily: font, flexShrink: 0 }}>
            {unblocking === uid ? "…" : "Unblock"}
          </button>
        </div>
      ))}
    </div>
  );
}

// ──────────────────────── Profile Tab (main view) ────────────────────────

export function ProfileTab({ user, onSignOut }: { user: User; onSignOut: () => void }) {
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [view, setView] = useState<"view" | "edit" | "blocked">("view");
  const [friendCount, setFriendCount] = useState(0);
  const [signingOut, setSigningOut] = useState(false);

  useEffect(() => {
    const unsub = onSnapshot(doc(db, "users", user.uid), (snap) => {
      if (snap.exists()) {
        const d = snap.data();
        setProfile({
          displayName: d.displayName ?? "", username: d.username ?? "",
          bio: d.bio ?? "", phone: d.phone ?? "", dob: d.dob ?? "",
          gender: d.gender ?? "", country: d.country ?? "", city: d.city ?? "",
          photoURL: d.photoURL ?? "", email: user.email ?? "",
          privacy: { showEmail: d.privacy?.showEmail ?? false, showPhone: d.privacy?.showPhone ?? false, visibility: d.privacy?.visibility ?? "friends" },
          createdAt: d.createdAt ?? null, online: d.online ?? false, lastSeen: d.lastSeen ?? null,
          blockedUsers: d.blockedUsers ?? [],
        });
      } else {
        setDoc(doc(db, "users", user.uid), {
          displayName: user.displayName ?? "", email: user.email ?? "",
          username: "", bio: "", phone: "", dob: "", gender: "", country: "", city: "", photoURL: "",
          privacy: { showEmail: false, showPhone: false, visibility: "friends" },
          online: true, lastSeen: null, blockedUsers: [], createdAt: serverTimestamp(),
        }, { merge: true });
      }
    });
    return unsub;
  }, [user.uid]);

  useEffect(() => {
    setDoc(doc(db, "users", user.uid), { online: true, lastSeen: serverTimestamp() }, { merge: true });
    return () => { setDoc(doc(db, "users", user.uid), { online: false, lastSeen: serverTimestamp() }, { merge: true }).catch(() => {}); };
  }, [user.uid]);

  useEffect(() => {
    let c1 = 0, c2 = 0;
    const q1 = query(collection(db, "friendRequests"), where("from", "==", user.uid), where("status", "==", "accepted"));
    const q2 = query(collection(db, "friendRequests"), where("to", "==", user.uid), where("status", "==", "accepted"));
    const u1 = onSnapshot(q1, (s) => { c1 = s.size; setFriendCount(c1 + c2); }, () => {});
    const u2 = onSnapshot(q2, (s) => { c2 = s.size; setFriendCount(c1 + c2); }, () => {});
    return () => { u1(); u2(); };
  }, [user.uid]);

  const updatePrivacy = (key: string, value: boolean | string) =>
    setDoc(doc(db, "users", user.uid), { privacy: { [key]: value } }, { merge: true });

  const handleSignOut = async () => {
    setSigningOut(true);
    try {
      await setDoc(doc(db, "users", user.uid), { online: false, lastSeen: serverTimestamp() }, { merge: true });
      await signOut(auth);
      onSignOut();
    } finally { setSigningOut(false); }
  };

  const formatJoinDate = (ts: Timestamp | null) => ts ? ts.toDate().toLocaleDateString([], { month: "short", year: "numeric" }) : "—";
  const formatLastSeen = (ts: Timestamp | null, online: boolean) => {
    if (online) return "Online";
    if (!ts) return "—";
    const diff = Date.now() - ts.toDate().getTime();
    if (diff < 60000) return "Just now";
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    return ts.toDate().toLocaleDateString([], { month: "short", day: "numeric" });
  };

  if (!profile) {
    return (
      <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center" }}>
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
        <div style={{ width: 32, height: 32, borderRadius: "50%", border: `3px solid rgba(124,58,237,0.2)`, borderTopColor: ACCENT, animation: "spin 0.8s linear infinite" }} />
      </div>
    );
  }

  if (view === "edit") return <EditProfileView user={user} profile={profile} onBack={() => setView("view")} />;
  if (view === "blocked") return <BlockedUsersView profile={profile} userId={user.uid} onBack={() => setView("view")} />;

  const vis = profile.privacy.visibility;
  const initials = (profile.displayName || user.email || "?").slice(0, 2).toUpperCase();

  return (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", overflowY: "auto" }}>
      {/* Header */}
      <div style={{ padding: "24px 22px 16px", display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center" }}>
        <div style={{ position: "relative", marginBottom: 14 }}>
          <div style={{ width: 88, height: 88, borderRadius: 28, background: `linear-gradient(135deg, ${ACCENT}99, ${ACCENT2}44)`, border: `2px solid ${ACCENT}55`, overflow: "hidden", boxShadow: "0 8px 24px rgba(124,58,237,0.35)" }}>
            {profile.photoURL
              ? <img src={profile.photoURL} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
              : <div style={{ width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 28, fontWeight: 700, color: "#fff" }}>{initials}</div>
            }
          </div>
          <div style={{ position: "absolute", bottom: 2, right: 2, width: 18, height: 18, borderRadius: "50%", background: profile.online ? "#34d399" : MUTED, border: "2.5px solid #0c0c1a" }} />
        </div>

        <h2 style={{ fontSize: 20, fontWeight: 700, color: "#f1f5f9", margin: "0 0 3px", letterSpacing: "-0.3px" }}>
          {profile.displayName || user.email?.split("@")[0] || "User"}
        </h2>
        {profile.username && <p style={{ fontSize: 14, color: "#a78bfa", margin: "0 0 6px", fontWeight: 600 }}>@{profile.username}</p>}
        {profile.bio && <p style={{ fontSize: 13, color: MUTED, margin: "0 0 8px", lineHeight: 1.5, maxWidth: 280 }}>{profile.bio}</p>}
        {(profile.city || profile.country) && (
          <p style={{ fontSize: 12, color: MUTED, margin: 0, display: "flex", alignItems: "center", gap: 4 }}>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0z"/><circle cx="12" cy="10" r="3"/></svg>
            {[profile.city, profile.country].filter(Boolean).join(", ")}
          </p>
        )}
      </div>

      {/* Stats */}
      <div style={{ margin: "0 16px 14px", background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: 16, padding: "14px 0", display: "flex" }}>
        {[
          { label: "Friends", value: String(friendCount), gradient: true },
          { label: "Joined", value: formatJoinDate(profile.createdAt), gradient: false },
          { label: "Status", value: profile.online ? "Online" : formatLastSeen(profile.lastSeen, false), gradient: false, color: profile.online ? "#34d399" : undefined },
        ].map((s, i, arr) => (
          <div key={s.label} style={{ flex: 1, textAlign: "center", borderRight: i < arr.length - 1 ? `1px solid ${BORDER}` : "none" }}>
            <p style={{ fontSize: s.gradient ? 20 : 13, fontWeight: 700, color: s.color ?? "#f1f5f9", margin: 0, ...(s.gradient ? { background: GRAD, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" } : {}) }}>
              {s.value}
            </p>
            <p style={{ fontSize: 11, color: MUTED, margin: "3px 0 0" }}>{s.label}</p>
          </div>
        ))}
      </div>

      {/* Privacy */}
      <SectionCard title="Privacy">
        <SettingRow label="Show Email" sub={profile.privacy.showEmail ? user.email ?? "" : "Hidden"} right={<Toggle value={profile.privacy.showEmail} onChange={(v) => updatePrivacy("showEmail", v)} />} />
        <SettingRow label="Show Phone Number" sub={profile.privacy.showPhone ? (profile.phone || "Not set") : "Hidden"} right={<Toggle value={profile.privacy.showPhone} onChange={(v) => updatePrivacy("showPhone", v)} />} />
        <div style={{ padding: "13px 18px", borderBottom: `1px solid ${BORDER}` }}>
          <p style={{ fontSize: 14, color: "#f1f5f9", margin: "0 0 10px", fontWeight: 500 }}>Profile Visibility</p>
          <div style={{ display: "flex", gap: 6 }}>
            {(["public", "friends", "private"] as const).map((v) => (
              <button key={v} onClick={() => updatePrivacy("visibility", v)} style={{
                flex: 1, background: vis === v ? GRAD : FIELD_BG,
                border: `1px solid ${vis === v ? "transparent" : BORDER}`,
                borderRadius: 10, padding: "8px 4px", fontSize: 12, fontWeight: 600,
                color: vis === v ? "#fff" : MUTED, cursor: "pointer", fontFamily: font,
                boxShadow: vis === v ? "0 2px 8px rgba(124,58,237,0.3)" : "none",
                transition: "all 0.2s", textTransform: "capitalize",
              }}>{v}</button>
            ))}
          </div>
        </div>
        <SettingRow label="Public Profile" sub={vis === "public" ? "Anyone can view your profile" : vis === "friends" ? "Only friends can view" : "Nobody can view your profile"} />
      </SectionCard>

      {/* Settings */}
      <SectionCard title="Settings">
        <SettingRow label="Edit Profile" sub="Update name, photo, bio and more" onClick={() => setView("edit")} />
        <SettingRow label="Account Email" sub={user.email ?? ""} />
        {profile.dob && <SettingRow label="Date of Birth" sub={profile.dob} />}
        {profile.gender && <SettingRow label="Gender" sub={profile.gender} />}
      </SectionCard>

      {/* Social */}
      <SectionCard title="Social">
        <SettingRow label="Friend Count" sub="Visible to all friends" right={<span style={{ fontSize: 14, fontWeight: 700, color: "#a78bfa" }}>{friendCount}</span>} />
        <SettingRow label="Online Status" sub="Shows when you're active" right={<Toggle value={profile.online} onChange={() => {}} />} />
        <SettingRow label="Last Seen" sub={formatLastSeen(profile.lastSeen, profile.online)} />
        <SettingRow label="Join Date" sub={formatJoinDate(profile.createdAt)} />
      </SectionCard>

      {/* Safety */}
      <SectionCard title="Safety">
        <SettingRow label="Blocked Users" sub={profile.blockedUsers.length > 0 ? `${profile.blockedUsers.length} blocked` : "No one blocked"} onClick={() => setView("blocked")} />
      </SectionCard>

      {/* Sign Out */}
      <div style={{ margin: "4px 16px 24px" }}>
        <button onClick={handleSignOut} disabled={signingOut} style={{
          width: "100%", background: signingOut ? "rgba(239,68,68,0.05)" : "rgba(239,68,68,0.08)",
          border: "1px solid rgba(239,68,68,0.2)", borderRadius: 13, padding: "15px",
          fontSize: 15, fontWeight: 600, color: "#fca5a5", cursor: "pointer", fontFamily: font,
        }}>
          {signingOut ? "Signing out…" : "Sign Out"}
        </button>
      </div>
    </div>
  );
}
